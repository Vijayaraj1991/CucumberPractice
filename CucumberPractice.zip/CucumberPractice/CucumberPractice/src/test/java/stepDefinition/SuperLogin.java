package stepDefinition;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class SuperLogin {
	
	WebDriver driver;
	
	@Given("^user should be in to the superlogin page$")
	public void user_should_be_in_to_the_superlogin_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\vijayarajkr\\eclipse-workspace\\CucumberPractice\\src\\Driver\\chromedriver.exe");
				driver = new ChromeDriver();
				driver.get("https://opensource-demo.orangehrmlive.com/");
				
	    
	}

	@When("^user should be Entering the super login credentials$")
	public void user_should_be_Entering_the_super_login_credentials() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		
		driver.findElement(By.id("txtUsername")).sendKeys("Admin");
		driver.findElement(By.id("txtPassword")).sendKeys("admin123");
	
	}

	@When("^user can able to entering the credentials$")
	public void user_can_able_to_entering_the_credentials() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		
		driver.findElement(By.id("btnLogin")).click();
	    
	}

	@Then("^Go to the superlogin page and access\\.$")
	public void go_to_the_superlogin_page_and_access() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		
boolean status	=driver.findElement(By.partialLinkText("Admin")).isDisplayed();
		
		if(status) {
			
			System.out.println("Admin is displayed or not");
		}
		}
	   
	}



