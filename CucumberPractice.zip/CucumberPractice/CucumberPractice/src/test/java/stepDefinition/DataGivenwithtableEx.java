package stepDefinition;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class DataGivenwithtableEx {
	
	WebDriver driver;
	
	

	@Given("^moved to the login page and do some activities$")
	public void moved_to_the_login_page_and_do_some_activities() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\vijayarajkr\\eclipse-workspace\\CucumberPractice\\src\\Driver\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("https://opensource-demo.orangehrmlive.com/");
		
	}

	@When("^Please enter the following credentials \"([^\"]*)\" and \"([^\"]*)\" valid credentials$")
	public void please_enter_the_following_credentials_and_valid_credentials(String uname, String pwd) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		driver.findElement(By.id("txtUsername")).sendKeys(uname);
		driver.findElement(By.id("txtPassword")).sendKeys(pwd);
	}
	

	@When("^Given the details$")
	public void given_the_details() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		driver.findElement(By.id("btnLogin")).click();
	}

	@Then("^Its must be on the login page$")
	public void its_must_be_on_the_login_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
boolean status	=driver.findElement(By.partialLinkText("Admin")).isDisplayed();
		
		if(status) {
			
			System.out.println("Admin is displayed or not");
		}
		}
	}


