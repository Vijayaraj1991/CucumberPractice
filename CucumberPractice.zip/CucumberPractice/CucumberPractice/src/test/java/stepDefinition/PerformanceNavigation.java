package stepDefinition;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class PerformanceNavigation {
	
	WebDriver driver;
	
	@Given("^user click on performance page and its displayed all the related options$")
	public void user_click_on_performance_page_and_its_displayed_all_the_related_options() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\vijayarajkr\\eclipse-workspace\\CucumberPractice\\src\\Driver\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("https://opensource-demo.orangehrmlive.com/index.php/dashboard#");
		driver.manage().timeouts().implicitlyWait(5000, TimeUnit.SECONDS);
		driver.findElement(By.id("txtUsername")).sendKeys("Admin");
		driver.findElement(By.id("txtPassword")).sendKeys("admin123");
		driver.findElement(By.id("btnLogin")).click();
		
	   
	}

	@When("^the user should be in tracker reports$")
	public void the_user_should_be_in_tracker_reports() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		driver.findElement(By.xpath("//*[@id='menu__Performance']")).click();
	}

	@When("^its redirected to the steps$")
	public void its_redirected_to_the_steps() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		driver.findElement(By.xpath("//*[@id='menu_performance_viewEmployeePerformanceTrackerList']")).click();
	}

	@Then("^the reports should displayed$")
	public void the_reports_should_displayed() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		driver.quit();
	}
	

		
	  
	}


