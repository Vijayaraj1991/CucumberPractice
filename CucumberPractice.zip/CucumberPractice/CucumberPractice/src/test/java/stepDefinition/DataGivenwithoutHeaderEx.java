package stepDefinition;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class DataGivenwithoutHeaderEx {
	
	WebDriver driver;
	
	
	@Given("^Its should be passing the username and password via feature file$")
	public void its_should_be_passing_the_username_and_password_via_feature_file() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\vijayarajkr\\eclipse-workspace\\CucumberPractice\\src\\Driver\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("https://opensource-demo.orangehrmlive.com/");
		
	    
	}

	@When("^I enter the credentials below$")
	public void i_enter_the_credentials_below(DataTable machan) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    // For automatic transformation, change DataTable to one of
	    // List<YourType>, List<List<E>>, List<Map<K,V>> or Map<K,V>.
	    // E,K,V must be a scalar (String, Integer, Date, enum etc)
		
	List<String> credit =	machan.asList(String.class);
	
	String name = credit.get(0);
	String pwd = credit.get(1);
		
		
		driver.findElement(By.id("txtUsername")).sendKeys(name);
		driver.findElement(By.id("txtPassword")).sendKeys(pwd);
	}
	 

	@Then("^success the page$")
	public void success_the_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		
		driver.findElement(By.id("btnLogin")).click();
	    
	}
	

}
