package stepDefinition;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class OpenGoogleStepDefiition {
	
WebDriver driver;

	
	@Given("^user is entering the google\\.co\\.in$")
	public void user_is_entering_the_google_co_in() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\vijayarajkr\\eclipse-workspace\\CucumberPractice\\src\\DriverPath\\chromedriver.exe");
		driver = new ChromeDriver();
		
		driver.get("https://google.com");
		
		driver.manage().window().maximize();
		
		driver.manage().timeouts().implicitlyWait(5000, TimeUnit.SECONDS);
		
	    
	}

	@When("^user is typing the search term \"([^\"]*)\"$")
	public void user_is_typing_the_search_term(String search) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		
		driver.findElement(By.name("q")).sendKeys(search);
	   
	}

	@When("^enters the return key$")
	public void enters_the_return_key() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		driver.findElement(By.name("q")).sendKeys(Keys.RETURN);
	   
	}

	@Then("^the users should see the search results$")
	public void the_users_should_see_the_search_results() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		
	boolean status =	driver.findElement(By.partialLinkText("agin")).isDisplayed();
	
	if(status) {
		
		System.out.println("Its displayed");
	}
		
	    
	
	}


}
