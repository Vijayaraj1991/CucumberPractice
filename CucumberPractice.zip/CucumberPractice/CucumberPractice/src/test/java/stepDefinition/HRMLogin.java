package stepDefinition;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class HRMLogin {
	
	WebDriver driver;
	
	@Given("^user is in the login page$")
	public void user_is_in_the_login_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		//System.setProperty("webdriver.chrome.driver", "C:\\Users\\vijayarajkr\\eclipse-workspace\\CucumberPractice\\src\\Driver\\chromedriver.exe");
		//driver = new ChromeDriver();
		//driver.get("https://opensource-demo.orangehrmlive.com/");
		
	}

	@When("^they given the valid user \"([^\"]*)\" name and valid pwd \"([^\"]*)\"$")
	public void they_given_the_valid_user_name_and_valid_pwd(String username, String pwd) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		driver.findElement(By.id("txtUsername")).sendKeys(username);
		driver.findElement(By.id("txtPassword")).sendKeys(pwd);
	}

	@When("^click on the submit button$")
	public void click_on_the_submit_button() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		driver.findElement(By.id("btnLogin")).click();
	}

	@Then("^user in to the welocme home page\\.$")
	public void user_in_to_the_welocme_home_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		boolean status	=driver.findElement(By.partialLinkText("Admin")).isDisplayed();
		
		if(status) {
			
			System.out.println("Admin is displayed or not");
		}
		}

	}


	
	
	
	
	