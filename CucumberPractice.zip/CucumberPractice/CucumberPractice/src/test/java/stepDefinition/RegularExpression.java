package stepDefinition;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;

public class RegularExpression {
	
	@Given("^I have (\\d+) st grade in Engineering$")
	public void i_have_st_grade_in_Engineering(int count) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    System.out.println("Engineering "+count);
	}

	@Given("^I have (\\d+\\.\\d+) cgpa in last semester$")
	public void i_have_cgpa_in_last_semester(float number) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   System.out.println("last semester"+number);
	}

	@Then("^\"(.*?)\" is elder than \"(.*?)\" and \"(.*?)\"$")
	public void is_elder_than_and(String name1, String name2, String name3) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    System.out.println("Elder persons"+name1 +name2 +name3);
	}

}




